#!/bin/bash
BACKUP_DIR="$HOME/astro/backups"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
ARCHIVE="$BACKUP_DIR/geodac_text_backup_$TIMESTAMP.tar.gz"

mkdir -p "$BACKUP_DIR"

# Архивируем все .md, .txt, .yaml, .json, .py, .sh — всё, что текстовое
tar -czf "$ARCHIVE" \
    --exclude='*.pyc' \
    --exclude='__pycache__' \
    --exclude='*.log' \
    -C ~/astro \
    ./*.md ./*.txt ./*.yaml ./*.json ./*.py ./*.sh chatlog/ data/ ui/ tools/ 2>/dev/null

echo "✅ Бэкап текстовых файлов создан: $ARCHIVE"
ls -la "$ARCHIVE"
