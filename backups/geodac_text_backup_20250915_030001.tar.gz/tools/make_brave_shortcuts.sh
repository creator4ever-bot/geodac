#!/usr/bin/env bash
set -euo pipefail

# найти Brave
BIN=""
for b in brave-browser brave-browser-stable brave; do
  if command -v "$b" >/dev/null 2>&1; then BIN="$b"; break; fi
done
[ -n "$BIN" ] || { echo "Brave не найден (brave-browser/brave)"; exit 1; }

APPS="$HOME/.local/share/applications"
DESK="$HOME/Desktop"
CONF="$HOME/.config/BraveProfiles"
mkdir -p "$APPS" "$DESK" "$CONF"

CHAT_URL="${CHAT_URL:-https://chat.openai.com/}"
UI_URL="${UI_URL:-http://127.0.0.1:8080}"
# имя каталога профиля Brave, который ты используешь в основном браузере: "Default", "Profile 1", ...
PROFILE_DIR="${PROFILE_DIR:-Default}"

# опционально: прокси только для изолированного варианта
PROXY_FLAG=""
if [ "${PROXY:-}" != "" ]; then
  PROXY_FLAG="--proxy-server=${PROXY}"
fi

# UI (с автоподъёмом backend)
cat > "$APPS/GeoDAC-UI.desktop" <<EOF
[Desktop Entry]
Name=GeoDAC UI
Comment=GeoDAC — локальная панель управления
Exec=$HOME/astro/tools/start_ui_and_open.sh
Terminal=false
Type=Application
Categories=Office;Utility;
StartupWMClass=GeoDAC-UI
EOF

cat > "$APPS/GeoDAC-UI-Dark.desktop" <<EOF
[Desktop Entry]
Name=GeoDAC UI (Dark)
Comment=GeoDAC — локальная панель управления (темный режим)
Exec=env FLAGS="--force-dark-mode --enable-features=WebUIDarkMode,WebContentsForceDark" $HOME/astro/tools/start_ui_and_open.sh
Terminal=false
Type=Application
Categories=Office;Utility;
StartupWMClass=GeoDAC-UI
EOF

# Chat (reuse основного профиля)
cat > "$APPS/GeoDAC-Chat.desktop" <<EOF
[Desktop Entry]
Name=GeoDAC Chat
Comment=Chat (Brave App, основной профиль)
Exec=$BIN --app="$CHAT_URL" --profile-directory="$PROFILE_DIR" --class=GeoDAC-Chat
Terminal=false
Type=Application
Categories=Network;Utility;
StartupWMClass=GeoDAC-Chat
EOF

cat > "$APPS/GeoDAC-Chat-Dark.desktop" <<EOF
[Desktop Entry]
Name=GeoDAC Chat (Dark)
Comment=Chat (Brave App, темный режим, основной профиль)
Exec=$BIN --app="$CHAT_URL" --profile-directory="$PROFILE_DIR" --class=GeoDAC-Chat-Dark --force-dark-mode --enable-features=WebUIDarkMode,WebContentsForceDark
Terminal=false
Type=Application
Categories=Network;Utility;
StartupWMClass=GeoDAC-Chat-Dark
EOF

# Изолированный вариант чата (если очень нужно отдельным профилем + прокси)
cat > "$APPS/GeoDAC-Chat-Isolated.desktop" <<EOF
[Desktop Entry]
Name=GeoDAC Chat (Isolated)
Comment=Chat (отдельный профиль, можно с прокси)
Exec=$BIN --app="$CHAT_URL" --user-data-dir="$CONF/GeoDAC-Chat-Isolated" --class=GeoDAC-Chat-Isolated $PROXY_FLAG --force-dark-mode --enable-features=WebUIDarkMode,WebContentsForceDark
Terminal=false
Type=Application
Categories=Network;Utility;
StartupWMClass=GeoDAC-Chat-Isolated
EOF

# дубли на рабочий стол
for f in GeoDAC-UI.desktop GeoDAC-UI-Dark.desktop GeoDAC-Chat.desktop GeoDAC-Chat-Dark.desktop GeoDAC-Chat-Isolated.desktop; do
  cp -f "$APPS/$f" "$DESK/$f"
  chmod +x "$DESK/$f"
done

update-desktop-database "$APPS" >/dev/null 2>&1 || true
xdg-desktop-menu forceupdate >/dev/null 2>&1 || true
command -v kbuildsycoca5 >/dev/null 2>&1 && kbuildsycoca5 >/dev/null 2>&1 || true

echo "OK: ярлыки обновлены."
echo "Профиль чата: --profile-directory=\"$PROFILE_DIR\" (сменить: PROFILE_DIR='Profile 1' ~/astro/tools/make_brave_shortcuts.sh)"
echo "Изолированный чат: GeoDAC-Chat-Isolated.desktop (для PROXY используй переменную PROXY=...)"
