#!/usr/bin/env bash
set -euo pipefail
LOG="$HOME/astro/logs/mundane.log"
MON="$HOME/astro/tools/monitor_push_log.py"
PUSH="$HOME/astro/push_mundane_managed.sh"

# очистим хвост для наглядности (не трём историю)
: > "$LOG" || true

# запускаем монитор
python "$MON" "$LOG" &
MONPID=$!

# запускаем пуш
set +e
"$PUSH"
RC=$?
set -e

# останавливаем монитор
kill $MONPID >/dev/null 2>&1 || true
echo
if [ $RC -eq 0 ]; then
  echo "[ok] mundane push finished"
else
  echo "[fail] mundane push rc=$RC (см. $LOG)"
fi
exit $RC
