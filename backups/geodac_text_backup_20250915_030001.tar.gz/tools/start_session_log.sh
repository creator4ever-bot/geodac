#!/bin/bash
LOG_DIR="$HOME/astro/chatlog"
TEMPLATE="$LOG_DIR/TEMPLATE.md"
TODAY=$(date +%Y-%m-%d)
SESSION_LOG="$LOG_DIR/${TODAY}_session.md"

if [ ! -f "$SESSION_LOG" ]; then
    echo "# [$(date +%Y-%m-%d)] Автосозданная сессия" > "$SESSION_LOG"
    echo "## Контекст" >> "$SESSION_LOG"
    echo "- Запущена сессия: $(date)" >> "$SESSION_LOG"
    echo "" >> "$SESSION_LOG"
    echo "## Решения" >> "$SESSION_LOG"
    echo "" >> "$SESSION_LOG"
    echo "## Действия" >> "$SESSION_LOG"
    echo "" >> "$SESSION_LOG"
    echo "## Следующие шаги" >> "$SESSION_LOG"
    echo "" >> "$SESSION_LOG"
    echo "✅ Файл сессии создан: $SESSION_LOG"
else
    echo "ℹ️ Сессия сегодня уже начата: $SESSION_LOG"
fi
