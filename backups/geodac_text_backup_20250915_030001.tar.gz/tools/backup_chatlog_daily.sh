#!/bin/bash
# GeoDAC — Ежедневный бэкап только GeoDAC-сессий
# Загружает .md-файлы напрямую в Gist (без архива)
# Запускать через cron: 59 23 * * *

source ~/astroenv/bin/activate

CHATLOG_DIR="$HOME/astro/chatlog"
TODAY=$(date +%Y-%m-%d)

# Ищем только файлы GeoDAC-сессий за сегодня
SESSION_FILES=()
while IFS= read -r -d '' file; do
    SESSION_FILES+=("$file")
done < <(find "$CHATLOG_DIR" -name "${TODAY}*_geodac_session.md" -type f -print0)

# Если нет файлов — выходим без ошибки
if [ ${#SESSION_FILES[@]} -eq 0 ]; then
    echo "ℹ️ Нет GeoDAC-сессий за $TODAY — бэкап не требуется."
    exit 0
fi

echo "📤 Найдено ${#SESSION_FILES[@]} файлов сессий. Загружаем в Gist..."

# Формируем команду gh gist create с динамическим списком файлов
CMD="gh gist create --public --desc \"GeoDAC Daily Sessions — $TODAY\""

for file in "${SESSION_FILES[@]}"; do
    # Берём только имя файла для Gist (без пути)
    filename=$(basename "$file")
    CMD="$CMD --filename \"$filename\" \"$file\""
done

# Выполняем команду
eval "$CMD" 2>&1 | tee /tmp/gh_output.log

if [ $? -eq 0 ]; then
    GIST_URL=$(grep -o 'https://gist.github.com/[^[:space:]]*' /tmp/gh_output.log | head -1)
    if [ -n "$GIST_URL" ]; then
        echo "✅ Бэкап загружен: $GIST_URL"
        echo "$GIST_URL" >> "$CHATLOG_DIR/backup_links.txt"
    else
        echo "⚠️ Gist создан, но URL не распознан."
    fi
else
    echo "❌ Ошибка публикации в Gist:"
    cat /tmp/gh_output.log
    exit 1
fi

# --- Автообновление главного recovery-файла ---

TODAY_FILE="$HOME/astro/astro_recovery_$TODAY.md"
DESKTOP_LINK="$HOME/Desktop/astro_recovery.md"

if [ ! -f "$TODAY_FILE" ]; then
    LATEST=$(ls -t $HOME/astro/astro_recovery_*.md 2>/dev/null | head -1)
    if [ -n "$LATEST" ] && [ -f "$LATEST" ]; then
        cp "$LATEST" "$TODAY_FILE"
        sed -i "s|GeoDAC — Recovery (Managed+, [0-9\-]*)|GeoDAC — Recovery (Managed+, $TODAY)|g" "$TODAY_FILE"
        sed -i "s|Обновлено: [0-9\-]*|Обновлено: $TODAY|g" "$TODAY_FILE"
        ln -sf "$TODAY_FILE" "$DESKTOP_LINK"
        echo "🔄 Создана новая версия recovery-файла: $TODAY_FILE"
    else
        echo "⚠️ Не найден шаблон recovery-файла для копирования."
    fi
fi

rm -f /tmp/gh_output.log
echo "✅ Процесс завершён успешно."

exit 0
