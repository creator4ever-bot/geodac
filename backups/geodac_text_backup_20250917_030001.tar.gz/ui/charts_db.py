# -*- coding: utf-8 -*-
import os, sqlite3, re, subprocess, shlex
from pathlib import Path
from typing import List, Dict

ASTRO = Path.home() / 'astro'
DB_PATH = ASTRO / '.state' / 'charts.db'
ENV_FILE = ASTRO / '.state' / 'natal_env.sh'
VENV_PY = Path.home() / 'astroenv' / 'bin' / 'python'

def ensure_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.execute('''
        CREATE TABLE IF NOT EXISTS charts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            date TEXT NOT NULL,
            time TEXT DEFAULT '00:00:00',
            tz TEXT DEFAULT 'Europe/Moscow',
            lat REAL NOT NULL,
            lon REAL NOT NULL,
            hsys TEXT DEFAULT 'P',
            place TEXT DEFAULT '',
            tags TEXT DEFAULT '',
            notes TEXT DEFAULT ''
        )
    ''')
    conn.execute('CREATE INDEX IF NOT EXISTS idx_charts_name ON charts(name)')
    conn.execute('CREATE INDEX IF NOT EXISTS idx_charts_key ON charts(name, date, time)')
    conn.commit(); conn.close()

def _dm_to_deg(s: str) -> float:
    s=(s or '').strip().upper()
    m=re.match(r'^(\d+)\s*([NSWE])\s*(\d+)$', s) or re.match(r'^(\d+)([NSWE])(\d+)$', s)
    if not m: raise ValueError(f"bad coord: {s}")
    deg=int(m.group(1)); hemi=m.group(2); mins=int(m.group(3))
    val=deg+mins/60.0
    if hemi in ('S','W'): val=-val
    return val

def _tz_from_raw(tz_raw: str) -> str:
    s=(tz_raw or '').strip()
    if not s: return 'UTC'
    if s.upper() in ('MSK','MSD','MOW','MOSCOW'): return 'Europe/Moscow'
    m=re.match(r'^([+\-])\s*(\d{1,2})(?::?(\d{2}))?$', s)
    if m:
        sign,hh,mm=m.group(1),int(m.group(2)),int(m.group(3) or 0)
        if mm==0: return f"Etc/GMT-{hh}" if sign=='+' else f"Etc/GMT+{hh}"
        return f"UTC{sign}{hh:02d}:{mm:02d}"
    return s

def parse_zet_line(line: str) -> dict:
    parts=[p.strip() for p in line.strip().strip(';').split(';')]
    if len(parts)<8: raise ValueError("need: name; date; time; tz; place; lat; lon; hsys; ...")
    name=parts[0]
    m=re.match(r'^(\d{2})\.(\d{2})\.(\d{4})$', parts[1]); 
    if not m: raise ValueError(f"bad date: {parts[1]}")
    dd,mm,yy=m.groups(); date_iso=f"{yy}-{mm}-{dd}"
    t=parts[2]; 
    if t.count(':')==1: t+=':00'
    tz=_tz_from_raw(parts[3]); place=parts[4]
    lat=_dm_to_deg(parts[5]); lon=_dm_to_deg(parts[6])
    hsys=(parts[7] or 'P').strip().upper()[:1]
    tags=''; notes=''
    if len(parts)>8:
        rest='; '.join(parts[8:])
        tags=';'.join(sorted(set(re.findall(r'!#\S+', rest))))
        notes=rest
    return {'name':name,'date':date_iso,'time':t,'tz':tz,
            'lat':lat,'lon':lon,'hsys':hsys,'place':place,'tags':tags,'notes':notes}

def add_chart(row: dict) -> int:
    ensure_db(); conn=sqlite3.connect(DB_PATH); cur=conn.cursor()
    cur.execute('''INSERT INTO charts (name,date,time,tz,lat,lon,hsys,place,tags,notes)
                   VALUES (?,?,?,?,?,?,?,?,?,?)''',
                (row['name'],row['date'],row['time'],row['tz'],row['lat'],row['lon'],
                 row['hsys'],row.get('place',''),row.get('tags',''),row.get('notes','')))
    conn.commit(); rid=cur.lastrowid; conn.close(); return rid

def list_charts(q: str = '', limit: int = 500) -> List[dict]:
    ensure_db(); conn=sqlite3.connect(DB_PATH); conn.row_factory=sqlite3.Row
    if q:
        ql=f"%{q}%"
        rows=conn.execute('''SELECT * FROM charts
                             WHERE name LIKE ? OR place LIKE ? OR tags LIKE ?
                             ORDER BY date DESC, time DESC LIMIT ?''', (ql,ql,ql,limit)).fetchall()
    else:
        rows=conn.execute('SELECT * FROM charts ORDER BY date DESC, time DESC LIMIT ?', (limit,)).fetchall()
    conn.close(); return [dict(r) for r in rows]

def update_chart(cid: int, row: dict) -> None:
    ensure_db(); conn=sqlite3.connect(DB_PATH)
    conn.execute('''UPDATE charts SET name=?, date=?, time=?, tz=?, lat=?, lon=?, hsys=?, place=?, tags=?, notes=?
                    WHERE id=?''',
                 (row['name'],row['date'],row['time'],row['tz'],row['lat'],row['lon'],
                  row['hsys'],row.get('place',''),row.get('tags',''),row.get('notes',''),cid))
    conn.commit(); conn.close()

def delete_chart(cid: int) -> None:
    ensure_db(); conn=sqlite3.connect(DB_PATH)
    conn.execute('DELETE FROM charts WHERE id=?', (cid,)); conn.commit(); conn.close()

def add_chart_from_zet(line: str) -> int:
    return add_chart(parse_zet_line(line))

def import_zet_dir(root: str, pattern: str='*.txt', dry_run: bool=True, update_existing: bool=False) -> dict:
    # упрощённый импорт каталога в SQLite (опционально)
    from pathlib import Path
    ensure_db(); base=Path(os.path.expanduser(root)); files=list(base.rglob(pattern)) if base.exists() else []
    conn=sqlite3.connect(DB_PATH); conn.row_factory=sqlite3.Row
    added=updated=skipped=errors=0
    def _find(row):
        r=conn.execute('''SELECT id FROM charts WHERE name=? AND date=? AND time=? AND ABS(lat-?)<=1e-4 AND ABS(lon-?)<=1e-4''',
                       (row['name'],row['date'],row['time'],row['lat'],row['lon'])).fetchone()
        return r[0] if r else None
    for fp in files:
        try:
            txt=fp.read_text(encoding='cp1251')
        except Exception:
            try: txt=fp.read_text(encoding='utf-8-sig')
            except Exception: errors+=1; continue
        for ln in txt.splitlines():
            if ';' not in ln: continue
            try: row=parse_zet_line(ln)
            except Exception: errors+=1; continue
            eid=_find(row)
            if eid:
                if update_existing and not dry_run:
                    update_chart(eid,row); updated+=1
                else:
                    skipped+=1
            else:
                if not dry_run:
                    add_chart(row); added+=1
    conn.close()
    return {'root':str(base),'files':len(files),'added':added,'updated':updated,'skipped':skipped,'errors':errors}

def set_active(cid: int) -> str:
    ensure_db(); conn=sqlite3.connect(DB_PATH); conn.row_factory=sqlite3.Row
    r=conn.execute('SELECT * FROM charts WHERE id=?', (cid,)).fetchone()
    conn.close()
    if not r: return "not found"
    ENV_FILE.parent.mkdir(parents=True, exist_ok=True)
    lines=[
        f"export NATAL_DATE='{r['date']}'",
        f"export NATAL_TIME='{r['time']}'",
        f"export NATAL_TZ='{r['tz']}'",
        f"export NATAL_LAT='{r['lat']}'",
        f"export NATAL_LON='{r['lon']}'",
        f"export NATAL_HSYS='{r['hsys']}'",
    ]
    ENV_FILE.write_text('\n'.join(lines)+'\n', encoding='utf-8')
    cmd=f"{VENV_PY} {ASTRO/'compute_natal_frame.py'}"
    subprocess.run(shlex.split(cmd), cwd=str(ASTRO), check=False)
    return "OK"
