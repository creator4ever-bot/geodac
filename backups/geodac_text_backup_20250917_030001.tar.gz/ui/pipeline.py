from __future__ import annotations
import os, json, subprocess, shlex
from pathlib import Path

ASTRO = Path.home() / 'astro'
VENV_PY = str(Path.home() / 'astroenv/bin/python')
ENV_FILE = ASTRO / '.state' / 'natal_env.sh'

def _base_env() -> dict:
    e = os.environ.copy()
    # EPHE: симлинк без пробелов, если есть
    ephe_link = Path.home() / 'ephe' / 'swiss'
    if not e.get('EPHE'):
        e['EPHE'] = str(ephe_link) if ephe_link.exists() else "/home/DAC/Zet9 GeoDAC/Swiss"
    e.setdefault('TZ', 'Europe/Moscow')
    # подхватим натальные переменные из .state/natal_env.sh (export VAR='...')
    if ENV_FILE.exists():
        for ln in ENV_FILE.read_text(encoding='utf-8').splitlines():
            ln = ln.strip()
            if ln.startswith('export '):
                k, v = ln.split(' ', 1)[1].split('=', 1)
                e[k] = v.strip().strip("'").strip('"')
    return e

def _run(cmd: str, cwd: Path | None = None, env: dict | None = None) -> tuple[int, str]:
    e = _base_env()
    if env: e.update(env)
    p = subprocess.Popen(shlex.split(cmd), cwd=str(cwd or ASTRO),
                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    out = []
    for line in p.stdout:
        out.append(line)
    code = p.wait()
    return code, ''.join(out)

def _json_count(path: Path) -> int:
    if not path.exists(): return 0
    d = json.loads(path.read_text(encoding='utf-8'))
    return len(d.get('events', d if isinstance(d, list) else []))

def env_info() -> dict:
    env = _base_env()
    info = {'TZ': env.get('TZ'), 'EPHE': env.get('EPHE')}
    nf = ASTRO / '.state' / 'natal_frame.json'
    info['cusps_ok'] = nf.exists()
    if nf.exists():
        try:
            d = json.loads(nf.read_text(encoding='utf-8'))
            info['natal'] = d.get('cfg', {})
        except Exception:
            info['natal'] = {}
    else:
        info['natal'] = {}
    return info

# PREVIEW

def preview_mundane(date_from: str, date_to: str, orb: str = '2', step_h: str = '12') -> dict:
    raw = ASTRO / 'mundane_feed.preview.raw.json'
    fix = ASTRO / 'mundane_feed.preview.fixed.json'
    merged = ASTRO / 'mundane_feed.preview.merged.json'
    gt = ASTRO / 'grand_trine.preview.json'

    # feed → stdout → raw.json
    code, out = _run(f'{VENV_PY} {ASTRO}/mundane_feed.py {date_from} {date_to}')
    raw.write_text(out, encoding='utf-8')

    # postfix
    _run(f'{VENV_PY} {ASTRO}/mundane_postfix.py {raw} {fix}')

    # пост-заполнитель (ретро + станции)
    _run(f'{VENV_PY} {ASTRO}/mundane_fill_post_desc.py {fix}')

    # grand trine (может дать 0 событий — это ок)
    _run(f'{VENV_PY} {ASTRO}/mundane_grand_trine_scan.py {date_from} {date_to} {gt}',
         env={'ORB': str(orb), 'STEP_H': str(step_h)})

    # merge FIX + GT
    A = json.loads(fix.read_text(encoding='utf-8')) if fix.exists() else {}
    B = json.loads(gt.read_text(encoding='utf-8')) if gt.exists() else {}
    evA = A.get('events', [])
    evB = B.get('events', [])
    uniq = {}
    for e in evA + evB:
        k = e.get('gd_id') or (e.get('summary', ''), e.get('peak', ''))
        uniq[k] = e
    events = sorted(uniq.values(), key=lambda x: x.get('peak') or x.get('start') or '')
    merged.write_text(json.dumps({'events': events}, ensure_ascii=False, indent=2), encoding='utf-8')

    return {'fix': len(evA), 'gt': len(evB), 'merged': len(events),
            'files': {'raw': str(raw), 'fix': str(fix), 'merged': str(merged)}}

def _preview_personal(src_name: str) -> dict:
    src = ASTRO / src_name
    fixed = ASTRO / f'{src_name}.preview.fixed.json'
    outp = ASTRO / f'{src_name.replace(".json","")}_for_ics.preview.json'
    # nat frame
    _run(f'{VENV_PY} {ASTRO}/compute_natal_frame.py')
    # fix houses
    _run(f'{VENV_PY} {ASTRO}/fix_houses_in_events.py {src} {fixed}')
    # render
    _run(f'{VENV_PY} {ASTRO}/render_for_ics.py {fixed} {outp}')
    return {'fixed': str(fixed), 'for_ics': str(outp), 'count': _json_count(outp)}

def preview_medium() -> dict:
    return _preview_personal('transits_medium.json')

def preview_long() -> dict:
    return _preview_personal('transits_long.json')

def preview_lunar() -> dict:
    raw = ASTRO / 'lunar_natal.json'
    fixed = ASTRO / 'lunar_natal.preview.fixed.json'
    ics = ASTRO / 'lunar_natal_for_ics.preview.json'
    merged = ASTRO / 'lunar_natal_merged.preview.json'
    _run(f'{VENV_PY} {ASTRO}/compute_natal_frame.py')
    _run(f'{VENV_PY} {ASTRO}/fix_houses_in_events.py {raw} {fixed}')
    _run(f'{VENV_PY} {ASTRO}/render_for_ics.py {fixed} {ics}')
    _run(f'{VENV_PY} {ASTRO}/lunar_merge_angles.py {ics} {merged}')
    return {'fixed': str(fixed), 'for_ics': str(ics), 'merged': str(merged),
            'count': _json_count(merged)}

# PUSH

def push(layer: str, min_events: int = 10, orb: str = '2', step_h: str = '12') -> str:
    script = {
        'mundane': 'push_mundane_managed.sh',
        'medium':  'push_medium_managed.sh',
        'long':    'push_long_managed.sh',
        'lunar':   'push_lunar_natal_managed.sh',
    }[layer]
    env = {'MIN_EVENTS': str(min_events)}
    if layer == 'mundane':
        env.update({'ORB': str(orb), 'STEP_H': str(step_h)})
    code, out = _run(str(ASTRO / script), env=env)
    return out

def tail_log(name: str, n: int = 300) -> str:
    p = ASTRO / 'logs' / f'{name}.log'
    if not p.exists(): return ''
    lines = p.read_text(encoding='utf-8').splitlines()
    return '\n'.join(lines[-n:])

def snapshot() -> str:
    cmds = [
        f'git -C {ASTRO} rev-parse --is-inside-work-tree || git -C {ASTRO} init',
        f'git -C {ASTRO} add -A',
        f'git -C {ASTRO} commit -m "snapshot UI" || true',
        f'git -C {ASTRO} tag -f stable-latest || true',
    ]
    out = []
    for c in cmds:
        _, o = _run(c)
        out.append(o)
    return '\n'.join(out)

def start_push_progress(layer: str, min_events=10, orb='2', step_h='12') -> int:
    import subprocess, shlex, os
    e = os.environ.copy()
    e.setdefault('TZ','Europe/Moscow')
    ephe_link = Path.home()/ 'ephe' / 'swiss'
    if not e.get('EPHE'):
        e['EPHE'] = str(ephe_link) if ephe_link.exists() else "/home/DAC/Zet9 GeoDAC/Swiss"
    if layer == 'mundane':
        e['MIN_EVENTS'] = str(min_events); e['ORB'] = str(orb); e['STEP_H'] = str(step_h)
    elif layer in ('medium','long','lunar'):
        e['MIN_EVENTS'] = str(min_events)
    wrapper = str(Path.home()/'astro'/'tools'/'push_with_progress.sh')
    cmd = f"{wrapper}"
    e['LAYER'] = layer
    proc = subprocess.Popen(shlex.split(cmd), cwd=str(ASTRO), env=e)
    return proc.pid

def read_push_status_layer(layer: str) -> dict:
    import json
    st = Path.home()/ 'astro' / '.state' / f'push_status_{layer}.json'
    if not st.exists():
        return {'percent': 0, 'stage': 'idle'}
    try:
        return json.loads(st.read_text(encoding='utf-8'))
    except Exception:
        return {'percent': 0, 'stage': 'idle'}
