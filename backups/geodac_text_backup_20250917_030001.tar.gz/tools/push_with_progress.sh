#!/usr/bin/env bash
set -euo pipefail
LAYER="${LAYER:-mundane}"   # mundane|medium|long|lunar
BASE="$HOME/astro"
LOG="$BASE/logs/${LAYER}.log"
case "$LAYER" in
  mundane) SCRIPT="$BASE/push_mundane_managed.sh" ;;
  medium)  SCRIPT="$BASE/push_medium_managed.sh" ;;
  long)    SCRIPT="$BASE/push_long_managed.sh" ;;
  lunar)   SCRIPT="$BASE/push_lunar_natal_managed.sh" ; LOG="$BASE/logs/lunar_natal.log" ;;
  *) echo "Unknown LAYER=$LAYER"; exit 1 ;;
esac
MON="$BASE/tools/monitor_push_log.py"
STATUS="$BASE/.state/push_status_${LAYER}.json"
PY="$HOME/astroenv/bin/python"

: > "$LOG" || true
"$PY" "$MON" "$LOG" "$STATUS" &
MONPID=$!

set +e
"$SCRIPT"
RC=$?
set -e

kill $MONPID >/dev/null 2>&1 || true
echo
[ $RC -eq 0 ] && echo "[ok] ${LAYER} push finished" || echo "[fail] ${LAYER} push rc=$RC (см. $LOG)"
exit $RC
