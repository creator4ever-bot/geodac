#!/bin/bash
# Wrapper для anacron — устанавливает окружение и запускает бэкап

export HOME="/home/DAC"
export USER="DAC"
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"

cd /home/DAC/astro 2>/dev/null || { echo "❌ Не удалось перейти в ~/astro" >> /home/DAC/astro/logs/anacron.log; exit 1; }

# Активируем venv
source /home/DAC/astroenv/bin/activate 2>/dev/null || { echo "❌ Не удалось активировать venv" >> /home/DAC/astro/logs/anacron.log; exit 1; }

# Проверяем, доступен ли gh
if ! command -v gh >/dev/null 2>&1; then
    echo "❌ gh не найден в PATH" >> /home/DAC/astro/logs/anacron.log
    exit 1
fi

# Проверяем авторизацию gh
if ! gh auth status >/dev/null 2>&1; then
    echo "❌ gh не авторизован" >> /home/DAC/astro/logs/anacron.log
    exit 1
fi

# Запускаем бэкап
echo "🚀 [$(date)] Запуск GeoDAC daily backup через anacron..." >> /home/DAC/astro/logs/anacron.log

/home/DAC/astro/tools/backup_chatlog_daily.sh >> /home/DAC/astro/logs/daily_backup.log 2>&1

EXIT_CODE=$?
if [ $EXIT_CODE -eq 0 ]; then
    echo "✅ [$(date)] УСПЕХ: GeoDAC daily backup завершён" >> /home/DAC/astro/logs/anacron.log
else
    echo "❌ [$(date)] ОШИБКА: GeoDAC daily backup провален (exit code $EXIT_CODE)" >> /home/DAC/astro/logs/anacron.log
fi

exit $EXIT_CODE
