#!/bin/bash
source ~/astroenv/bin/activate

CHATLOG_DIR="$HOME/astro/chatlog"
BACKUP_FILE="/tmp/geodac_chatlog_$(date +%Y-%m-%d).tar.gz"

# Архивируем только chatlog
tar -czf "$BACKUP_FILE" -C "$CHATLOG_DIR" .

# Публикуем в Gist (с описанием)
GIST_URL=$(gh gist create \
    --public \
    --filename "geodac_chatlog_$(date +%Y-%m-%d).tar.gz" \
    --desc "GeoDAC Chatlog Weekly Backup (auto)" \
    "$BACKUP_FILE" 2>/dev/null)

if [ $? -eq 0 ]; then
    echo "✅ Еженедельный бэкап загружен: $GIST_URL"
    # Сохраняем ссылку локально
    echo "$GIST_URL" >> "$CHATLOG_DIR/backup_links.txt"
else
    echo "❌ Ошибка публикации в Gist. Проверь авторизацию: gh auth status"
fi

# Удаляем временный файл
rm -f "$BACKUP_FILE"
