# -*- coding: utf-8 -*-
import os, re, json, glob
from pathlib import Path

try:
    import yaml
except Exception:
    yaml = None

ROOT = Path.home() / 'astro'

def to_float(x):
    if x is None: return None
    try: return float(str(x).strip().replace(',', '.'))
    except: return None

def read_yaml(p):
    if not yaml: return None
    try:
        return yaml.safe_load(open(p, encoding='utf-8'))
    except Exception:
        return None

def from_config_yaml():
    p = ROOT/'config.yaml'
    if not p.exists(): return {}
    d = read_yaml(p)
    natal = (d or {}).get('natal') or {}
    lat = to_float(natal.get('lat')); lon = to_float(natal.get('lon'))
    if not (lat and lon): return {}
    return {
        'date': natal.get('date'),
        'time': natal.get('time','00:00'),
        'tz':   natal.get('tz','UTC'),
        'lat':  lat,
        'lon':  lon,
        'house_system': (natal.get('house_system') or 'P')[:1],
        '_src': str(p)
    }

def from_natal_frame():
    p = ROOT/'.state'/'natal_frame.json'
    if not p.exists(): return {}
    try:
        d = json.load(open(p, encoding='utf-8'))
        cfg = d.get('cfg') or {}
        lat = to_float(cfg.get('lat')); lon = to_float(cfg.get('lon'))
        if not (lat and lon): return {}
        return {
            'date': cfg.get('date'),
            'time': cfg.get('time','00:00'),
            'tz':   cfg.get('tz','UTC'),
            'lat':  lat,
            'lon':  lon,
            'house_system': (cfg.get('hsys') or 'P')[:1],
            '_src': str(p)
        }
    except Exception:
        return {}

def from_data_files():
    for fn in ['data/natal.yaml','data/natal.yml','data/natal.json']:
        p = ROOT/fn
        if not p.exists(): continue
        try:
            if p.suffix.lower()=='.json':
                d = json.load(open(p, encoding='utf-8'))
            else:
                d = read_yaml(p)
            natal = d.get('natal', d)
            lat = to_float(natal.get('lat')); lon = to_float(natal.get('lon'))
            if not (lat and lon): continue
            return {
                'date': natal.get('date'),
                'time': natal.get('time','00:00'),
                'tz':   natal.get('tz','UTC'),
                'lat':  lat,
                'lon':  lon,
                'house_system': (natal.get('house_system') or 'P')[:1],
                '_src': str(p)
            }
        except Exception:
            continue
    return {}

PAT_DATE = re.compile(r"(?:natal|birth|dob).*?:?\s*['\"](\d{4}-\d{2}-\d{2})['\"]", re.I)
PAT_TIME = re.compile(r"(?:time|birth_time).*?:?\s*['\"](\d{2}:\d{2})['\"]", re.I)
PAT_TZ   = re.compile(r"(?:tz|timezone).*?:?\s*['\"]([A-Za-z_/\-+0-9]+)['\"]")
PAT_LAT  = re.compile(r"(?:lat|latitude)\s*[:=]\s*([\-0-9\.,]+)")
PAT_LON  = re.compile(r"(?:lon|longitude)\s*[:=]\s*([\-0-9\.,]+)")
PAT_HSYS = re.compile(r"(?:house_system|hsys)\s*[:=]\s*['\"]?([A-Za-z])['\"]?")

def scan_python_sources():
    candidates = []
    for p in ROOT.glob('*.py'):
        candidates.append(p)
    for p in (ROOT/'tools').glob('*.py'):
        candidates.append(p)
    for p in ROOT.glob('transits_*.py'):
        candidates.append(p)
    best={}
    for p in candidates:
        try:
            s = open(p, encoding='utf-8').read()
        except Exception:
            continue
        d={}
        m=PAT_DATE.search(s); d['date']=m.group(1) if m else None
        m=PAT_TIME.search(s); d['time']=m.group(1) if m else None
        m=PAT_TZ.search(s);   d['tz']  =m.group(1) if m else None
        m=PAT_LAT.search(s);  d['lat'] =to_float(m.group(1)) if m else None
        m=PAT_LON.search(s);  d['lon'] =to_float(m.group(1)) if m else None
        m=PAT_HSYS.search(s); d['house_system']= (m.group(1) if m else None)
        if d.get('lat') and d.get('lon'):
            d['_src']=str(p)
            # приоритезируем те, где есть date/time/tz
            score = sum(1 for k in ('date','time','tz','house_system') if d.get(k))
            d['_score']=score
            if (not best) or (score > best.get('_score', -1)):
                best = d
    return best

def main():
    for getter in (from_config_yaml, from_natal_frame, from_data_files, scan_python_sources):
        res = getter()
        if res and res.get('lat') and res.get('lon'):
            print("# source:", res.get('_src','(auto)'))
            date = res.get('date') or 'YYYY-MM-DD'
            time = res.get('time') or '00:00'
            tz   = res.get('tz')   or 'UTC'
            lat  = res.get('lat')
            lon  = res.get('lon')
            hsys = (res.get('house_system') or 'P')[:1]
            # печатаем готовые экспорты
            print(f"export NATAL_DATE='{date}'")
            print(f"export NATAL_TIME='{time}'")
            print(f"export NATAL_TZ='{tz}'")
            print(f"export NATAL_LAT='{lat}'")
            print(f"export NATAL_LON='{lon}'")
            print(f"export NATAL_HSYS='{hsys}'")
            return
    # если ничего не нашли
    print("# Не удалось автоматически извлечь натальные данные.")
    print("# Заполните вручную и выполните экспорт, например:")
    print("export NATAL_DATE='YYYY-MM-DD'")
    print("export NATAL_TIME='HH:MM'")
    print("export NATAL_TZ='Europe/Moscow'")
    print("export NATAL_LAT='55.7558'")
    print("export NATAL_LON='37.6173'")
    print("export NATAL_HSYS='P'")

if __name__=='__main__':
    main()
