#!/usr/bin/env bash
set -euo pipefail

URL="http://127.0.0.1:8099"
PY="$HOME/astroenv/bin/python"
APP="$HOME/astro/ui/app.py"
LOGDIR="$HOME/astro/logs"; mkdir -p "$LOGDIR"

# убить прежний бэкенд и поднять новый
pkill -f "python .*astro/ui/app.py" 2>/dev/null || true
sleep 0.5

nohup "$PY" -u "$APP" >> "$LOGDIR/ui.log" 2>&1 &
sleep 4

# открыть системным браузером
if command -v xdg-open >/dev/null 2>&1; then exec xdg-open "$URL"; fi
if command -v brave-browser >/dev/null 2>&1; then exec brave-browser "$URL"; fi
exec xdg-open "$URL" || true
