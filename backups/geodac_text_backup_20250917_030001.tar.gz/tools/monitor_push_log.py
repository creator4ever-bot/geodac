#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os, sys, time, json, re
from pathlib import Path

STAGES = [
    ('[feed] RAW size:',                             15, 'feed'),
    ('OK station enhance: dedup kept=',              25, 'station_enhance'),
    ('OK post-fill:',                                30, 'postfill'),
    ('OK triggers:',                                 55, 'eclipse_triggers'),
    ('OK merge:',                                    70, 'merge_ecl'),
    ('grand_trine_span.json events:',                80, 'grand_trine'),
    ('[merge] FIX:',                                 90, 'merge_final'),
    ('Upsert done:',                                100, 'upsert'),
]

def write_state(state_path, percent, stage, extra=None):
    state_path.parent.mkdir(parents=True, exist_ok=True)
    data = {'percent': percent, 'stage': stage, 'time': time.strftime('%F %T')}
    if extra: data.update(extra)
    tmp = state_path.with_suffix('.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    tmp.replace(state_path)

def progress_bar(pct, width=30):
    n = max(0, min(width, int(width*pct/100)))
    return '[' + '#' * n + '-' * (width-n) + f'] {pct:3d}%'

def monitor(log_path, state_path):
    # распознаём слой из первой строки "[...] <layer> start ..."
    percent = 0; stage = 'waiting'; layer = 'layer'
    write_state(state_path, percent, stage)
    for _ in range(200):
        if os.path.exists(log_path): break
        time.sleep(0.1)
    last_beat = time.time()
    try:
        with open(log_path, 'r', encoding='utf-8', errors='ignore') as f:
            f.seek(0, os.SEEK_END)
            while True:
                line = f.readline()
                if not line:
                    if time.time() - last_beat >= 5:
                        print('.', end='', flush=True)
                        last_beat = time.time()
                    time.sleep(0.2)
                    continue
                line = line.strip()
                if percent == 0 and ' start ' in line:
                    m = re.search(r'```\s+(\w+)\s+start', line)
                    if m:
                        layer = m.group(1)
                    percent = 5; stage = f'start:{layer}'
                    print('\r' + progress_bar(percent) + ' ' + stage + ' ' * 20, end='', flush=True)
                    write_state(state_path, percent, stage)
                    continue
                # этапы
                for key, pct, st in STAGES:
                    if key in line:
                        percent = max(percent, pct); stage = st
                        extra = None
                        if st == 'eclipse_triggers':
                            try:
                                # "OK triggers: N -> ..."
                                part = line.split('OK triggers:')[-1].strip()
                                n = int(part.split()[0])
                                extra = {'triggers': n}
                            except Exception:
                                pass
                        print('\r' + progress_bar(percent) + ' ' + stage + ' ' * 20, end='', flush=True)
                        write_state(state_path, percent, stage, extra)
                        break
                if ' done' in line and f' {layer} done' in line:
                    percent = 100; stage = 'done'
                    print('\r' + progress_bar(percent) + ' ' + stage + ' ' * 20)
                    write_state(state_path, percent, stage)
                    return
    except KeyboardInterrupt:
        pass

def main():
    if len(sys.argv) < 3:
        print("Usage: monitor_push_log.py LOGFILE STATUS_JSON"); sys.exit(1)
    log = os.path.expanduser(sys.argv[1])
    st  = Path(os.path.expanduser(sys.argv[2]))
    monitor(log, st)

if __name__ == '__main__':
    main()
